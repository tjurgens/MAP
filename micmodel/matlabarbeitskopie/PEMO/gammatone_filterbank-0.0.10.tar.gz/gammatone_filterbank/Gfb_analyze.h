/* 
 * This file is part of the gammatone filterbank reference implementation
 * described in V. Hohmann's `acta acustica' article.
 *
 * It contains prototypes for a C function that implements filter bank
 * analysis.
 *
 * filename : Gfb_analyze.h
 * copyright: Universitaet Oldenburg
 * author   : tp
 * date     : Jan 2002
 *
 * update   : 
 */

/*-----------------------------------------------------------------------------
 *   Copyright (C) 2002   AG Medizinische Physik,
 *                        Universitaet Oldenburg, Germany
 *                        http://www.physik.uni-oldenburg.de/docs/medi
 *   
 *   Permission to use, copy, and distribute this software/file and its
 *   documentation for any purpose without permission by UNIVERSITAET OLDENBURG
 *   is not granted.
 *   
 *   Permission to use this software for academic purposes is generally
 *   granted.
 *
 *   Permission to modify the software is granted, but not the right to
 *   distribute the modified code.
 *
 *   This software is provided "as is" without expressed or implied warranty.
 *
 *   Author: Tobias Peters (tobias@medi.physik.uni-oldenburg.de)
 *---------------------------------------------------------------------------*/

#ifndef GFB_ANALYZER_FPROCESS_ANALYZE_H
#define GFB_ANALYZER_FPROCESS_ANALYZE_H

#ifdef __cplusplus
extern "C" {
#endif

  /**
   * gfb_analyze_dd implements the filter bank analysis as a C function.
   * data input and output is done in doubles, and the computation is performed
   * with doubles as well.
   *
   * @param channels        number of gammatone filters in this filterbank
   * @param gamma           gammatone filter order (usually == 4)
   * @param samples         number of samples in input signal
   * @param real_filter_coefficients
   *                        a vector holding the real parts of each channel's
   *                        filter coefficients
   * @param imag_filter_coefficients
   *                        a vector holding the imaginary parts of each
   *                        channel's filter coefficients
   * @param normalization_factors
   *                        a vector containing the normalization factors of
   *                        the individual gammatone filter channels
   * @param real_filter_states
   *                        a vector holding the real parts of each channels
   *                        filter states. The filter state part corresponding
   *                        to a specific channel and filter stage is stored at
   *                        index [channel * filter_order + filter_stage],
   *                        where filter_order denotes the order of the
   *                        gammatone filters (usually == 4).
   * @param imag_filter_states
   *                        a vector holding the imaginary parts of each
   *                        channel's filter states
   * @param input           a vector containing the (pure real) input samples
   * @param output1         a pointer to the array where the filterbank output
   *                        is stored by this function.
   *                        <br>
   *                        If the next parameter, output2, is NULL, then the
   *                        real real part of the filterbank output and the
   *                        imaginary part are stored interlaced on this array.
   *                        The real output corresponding to a particular
   *                        channel and sample can then be found be found at
   *                        index [2 * (channel + sample * channels)], while
   *                        the corresponding imaginary output is located at
   *                        index [2 * (channel + sample * channels) + 1].
   *                        <br>
   *                        If the parameter output2 is not NULL, then only the
   *                        real part of the output signal is stored in this
   *                        array, and the real output corresponding to a
   *                        particular channel and sample can then be found be
   *                        found at index [channel + sample * channels]
   * @param output2         the array for the imaginary output.  This pointer
   *                        may be NULL, in which case the imaginary part is
   *                        stored interlaced with the real output in the
   *                        array pointed to by output1
   */ 
   void gfb_analyze_dd(const unsigned       channels,
		       const unsigned       gamma,
		       const unsigned       samples,
		       const double * const real_filter_coefficients,
		       const double * const imag_filter_coefficients,
		       const double * const normalization_factors,
		       double * const       real_filter_states,
		       double * const       imag_filter_states,
		       const double *       input,
		       double *             real_output,
		       double *             imag_output);

  /**
   * gfb_analyze_df implements the filter bank analysis as a C function.
   * data input and output is done in doubles, butthe computation is performed
   * with floats (single precicion).
   *
   * @param channels        number of gammatone filters in this filterbank
   * @param gamma           gammatone filter order (usually == 4)
   * @param samples         number of samples in input signal
   * @param real_filter_coefficients
   *                        a vector holding the real parts of each channel's
   *                        filter coefficients
   * @param imag_filter_coefficients
   *                        a vector holding the imaginary parts of each
   *                        channel's filter coefficients
   * @param normalization_factors
   *                        a vector containing the normalization factors of
   *                        the individual gammatone filter channels
   * @param real_filter_states
   *                        a vector holding the real parts of each channels
   *                        filter states. The filter state part corresponding
   *                        to a specific channel and filter stage is stored at
   *                        index [channel * filter_order + filter_stage],
   *                        where filter_order denotes the order of the
   *                        gammatone filters (usually == 4).
   * @param imag_filter_states
   *                        a vector holding the imaginary parts of each
   *                        channel's filter states
   * @param input           a vector containing the (pure real) input samples
   * @param output1         a pointer to the array where the filterbank output
   *                        is stored by this function.
   *                        <br>
   *                        If the next parameter, output2, is NULL, then the
   *                        real real part of the filterbank output and the
   *                        imaginary part are stored interlaced on this array.
   *                        The real output corresponding to a particular
   *                        channel and sample can then be found be found at
   *                        index [2 * (channel + sample * channels)], while
   *                        the corresponding imaginary output is located at
   *                        index [2 * (channel + sample * channels) + 1].
   *                        <br>
   *                        If the parameter output2 is not NULL, then only the
   *                        real part of the output signal is stored in this
   *                        array, and the real output corresponding to a
   *                        particular channel and sample can then be found be
   *                        found at index [channel + sample * channels]
   * @param output2         the array for the imaginary output.  This pointer
   *                        may be NULL, in which case the imaginary part is
   *                        stored interlaced with the real output in the
   *                        array pointed to by output1
   */ 
  void gfb_analyze_df(const unsigned      channels,
		      const unsigned      gamma,
		      const unsigned      samples,
		      const float * const real_filter_coefficients,
		      const float * const imag_filter_coefficients,
		      const float * const normalization_factors,
		      float * const       real_filter_states,
		      float * const       imag_filter_states,
		      const double *      input,
		      double *            real_output,
		      double *            imag_output);

  /**
   * gfb_analyze_ff implements the filter bank analysis as a C function.
   * data input and output is done in floats, and the computation is performed
   * with floats in single precision as well.
   *
   * @param channels        number of gammatone filters in this filterbank
   * @param gamma           gammatone filter order (usually == 4)
   * @param samples         number of samples in input signal
   * @param real_filter_coefficients
   *                        a vector holding the real parts of each channel's
   *                        filter coefficients
   * @param imag_filter_coefficients
   *                        a vector holding the imaginary parts of each
   *                        channel's filter coefficients
   * @param normalization_factors
   *                        a vector containing the normalization factors of
   *                        the individual gammatone filter channels
   * @param real_filter_states
   *                        a vector holding the real parts of each channels
   *                        filter states. The filter state part corresponding
   *                        to a specific channel and filter stage is stored at
   *                        index [channel * filter_order + filter_stage],
   *                        where filter_order denotes the order of the
   *                        gammatone filters (usually == 4).
   * @param imag_filter_states
   *                        a vector holding the imaginary parts of each
   *                        channel's filter states
   * @param input           a vector containing the (pure real) input samples
   * @param output1         a pointer to the array where the filterbank output
   *                        is stored by this function.
   *                        <br>
   *                        If the next parameter, output2, is NULL, then the
   *                        real real part of the filterbank output and the
   *                        imaginary part are stored interlaced on this array.
   *                        The real output corresponding to a particular
   *                        channel and sample can then be found be found at
   *                        index [2 * (channel + sample * channels)], while
   *                        the corresponding imaginary output is located at
   *                        index [2 * (channel + sample * channels) + 1].
   *                        <br>
   *                        If the parameter output2 is not NULL, then only the
   *                        real part of the output signal is stored in this
   *                        array, and the real output corresponding to a
   *                        particular channel and sample can then be found be
   *                        found at index [channel + sample * channels]
   * @param output2         the array for the imaginary output.  This pointer
   *                        may be NULL, in which case the imaginary part is
   *                        stored interlaced with the real output in the
   *                        array pointed to by output1
   */ 
  void gfb_analyze_ff(const unsigned      channels,
		      const unsigned      gamma,
		      const unsigned      samples,
		      const float * const real_filter_coefficients,
		      const float * const imag_filter_coefficients,
		      const float * const normalization_factors,
		      float * const       real_filter_states,
		      float * const       imag_filter_states,
		      const float *       input,
		      float *             real_output,
		      float *             imag_output);
#ifdef __cplusplus
}
#endif
#endif

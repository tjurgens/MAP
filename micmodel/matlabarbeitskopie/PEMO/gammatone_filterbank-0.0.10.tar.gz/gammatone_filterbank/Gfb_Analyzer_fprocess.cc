/* 
 * This file is part of the gammatone filterbank reference implementation
 * described in V. Hohmann's `acta acustica' article.
 *
 * It implements interface function between octave and the filter bank
 * analysis C function. See file "README_extension.txt" for a description
 * how to use the C function with octave.
 * Gfb_Analyzer_fprocess is a dynamic octave function with the same
 * functionality as Gfb_Analyzer_process: It performs the filterbank analysis
 * as described in the `acta acustica' article.
 *
 * filename : Gfb_Analyzer_fprocess.cc
 * copyright: Universitaet Oldenburg
 * author   : tp
 * date     : Jan 2002
 *
 * update   : 
 */

/*-----------------------------------------------------------------------------
 *   Copyright (C) 2002   AG Medizinische Physik,
 *                        Universitaet Oldenburg, Germany
 *                        http://www.physik.uni-oldenburg.de/docs/medi
 *   
 *   Permission to use, copy, and distribute this software/file and its
 *   documentation for any purpose without permission by UNIVERSITAET OLDENBURG
 *   is not granted.
 *   
 *   Permission to use this software for academic purposes is generally
 *   granted.
 *
 *   Permission to modify the software is granted, but not the right to
 *   distribute the modified code.
 *
 *   This software is provided "as is" without expressed or implied warranty.
 *
 *   Author: Tobias Peters (tobias@medi.physik.uni-oldenburg.de)
 *---------------------------------------------------------------------------*/

#include <strstream>
#include <octave/oct.h>
#include <octave/ov-struct.h>
#include <octave/ov.h>
#include "Gfb_analyze.c"

// Helper function for accessing the individual filter structures in the
// filterbank analyzer
static std::string filter_fieldname(unsigned channel)
{
  std::string    retval;
  std::strstream name_generator;
  name_generator << "filter" << channel;
  name_generator >> retval;
  return retval;
}

// The octave interface function. It checks for proper arguments,
// extracts the needed data from the input arguments and creates the output
// arguments.
DEFUN_DLD (Gfb_Analyzer_fprocess, args, nargout,
           "Gfb_Analyzer_fprocess is an octave extension with the same\n"
           "functionality as Gfb_Analyzer_process. It is called automati-\n"
           "cally from Gfb_Analyzer_process if the Gfb_Analyzer object con-\n"
           "tains a field named `fast' with a nonzero value.\n\n"
           "For details on how to use this function, please see the help for\n"
           "Gfb_Analyzer_process")
{
  // The return parameters are stored in this list:
  octave_value_list retval;

  // Check for proper number of arguments
  if (args.length() != 2) {
    error("Gfb_Analyzer_fprocess: needs 2 input arguments");
    return retval;
  }
  if (nargout > 2) {
    error("Gfb_Analyzer_fprocess: returns one or two parameters");
    return retval;
  }

  // Check second argument. Accept real row vector or scalar
  if (args(1).is_real_matrix() == false
      || (args(1).rows() != 1 && args(1).columns() != 1)) {
    if (args(1).is_real_scalar() == false) {
      error("Gfb_Analyzer_fprocess: 2nd argument must be a real vector");
      return retval;
    }
  }
  RowVector input =
    args(1).is_real_scalar()
    ? args(1).matrix_value().row(0)
    : args(1).vector_value().transpose();
  const unsigned samples = input.length();

  // Check first argument. Accept only Gfb_Analyzer structure
  if (args(0).is_map() == false) {
    error("Gfb_Analyzer_fprocess: 1st argument must be a Gfb_Analyzer "
	  "structure");
    return retval;
  }
  Octave_map analyzer = args(0).map_value();
  if (analyzer.contains("type") == false
      || analyzer["type"].is_string() == false
      || analyzer["type"].string_value() != "Gfb_Analyzer") {
    error("Gfb_Analyzer_fprocess: 1st argument must be a Gfb_Analyzer "
	  "structure");
    return retval;
  }

  octave_value center_frequencies_hz_ov = analyzer["center_frequencies_hz"];
  if (center_frequencies_hz_ov.is_real_matrix() == false
      || center_frequencies_hz_ov.rows() > 1) {
    error("Gfb_Analyzer_fprocess: 1st argument must be a Gfb_Analyzer\n"
	  "       structure, and must contain a real column vector\n"
	  "       field named `center_frequencies_hz'.  Use the\n"
	  "       Gfb_Analyzer_new function to construct a valid\n"
	  "       Gfb_Analyzer structure");
    return retval;
  }
  const unsigned channels = center_frequencies_hz_ov.columns();
  if (channels == 0) {
    retval(0) = ComplexMatrix(0, samples);
    if (nargout == 2) {
      retval(1) = analyzer;
    }
    return retval;
  }
  if (analyzer.contains("filters") == false
      || analyzer["filters"].is_map() == false
      || analyzer["filters"].map_value().contains("filter1") == false
      || analyzer["filters"].map_value()["filter1"].is_map() == false
      || (analyzer["filters"].map_value()["filter1"].map_value().
	  contains("gamma_order") == false)
      || (analyzer["filters"].map_value()["filter1"].
	  map_value()["gamma_order"].is_real_scalar() == false)) {
    error("Gfb_Analyzer_fprocess: 1st argument must be a Gfb_Analyzer\n"
	  "       structure, and must contain a structure field named\n"
	  "       `filters', containing the filter specifications.  Use\n"
	  "       the Gfb_Analyzer_new function to construct a valid\n"
	  "       Gfb_Analyzer structure");
    return retval;
  }
  Octave_map filters = analyzer["filters"].map_value();
  unsigned gamma_order =
    unsigned(filters["filter1"].map_value()["gamma_order"].double_value());

  retval(0) = double(gamma_order);

  // Helper struct that contains the filter parameters. We rely on its
  // destructor to delete allocated memory when it goes out of scope.
  struct Filterbank_Data {
    double * normalization_factors   ;
    double * real_filter_coefficients; double * imag_filter_coefficients;
    double * real_filter_state       ; double * imag_filter_state       ;
    Filterbank_Data(unsigned channels, unsigned gamma_order)
    {
      normalization_factors    = new double[channels];              
      real_filter_coefficients = new double[channels];              
      imag_filter_coefficients = new double[channels];              
      real_filter_state        = new double[channels * gamma_order];
      imag_filter_state        = new double[channels * gamma_order];
    }
    ~Filterbank_Data()
    {
      delete [] normalization_factors; delete [] real_filter_coefficients;
      delete [] imag_filter_coefficients; delete [] real_filter_state;
      delete [] imag_filter_state;
    }
  };
  Filterbank_Data fbd(channels, gamma_order);

  for (unsigned channel = 0; channel < channels; ++channel) {
    std::string fieldname = filter_fieldname(channel + 1);
    if (filters.contains(fieldname) == false
	|| filters[fieldname].is_map() == false) {
      error("Gfb_Analyzer_fprocess: 1st argument must be a Gfb_Analyzer\n"
	    "       structure, and must contain a structure field named\n"
	    "       `filters', containing the filter specifications.  Use\n"
	    "       the Gfb_Analyzer_new function to construct a valid\n"
	    "       Gfb_Analyzer structure");
      return retval;
    }
    Octave_map filter = filters[fieldname].map_value();
    if (filter.contains("type") == false
	|| filter["type"].is_string() == false
	|| filter["type"].string_value() != "Gfb_Filter"
	|| filter.contains("state") == false
	|| filter.contains("normalization_factor") == false
	|| filter.contains("coefficient") == false) {
      error("Gfb_Analyzer_fprocess: 1st argument must be a Gfb_Analyzer\n"
	    "       structure, and must contain a structure field named\n"
	    "       `filters', containing valid filter specifications.\n"
	    "       Use the Gfb_Analyzer_new function to construct a\n"
	    "       valid Gfb_Analyzer structure");
      return retval;
    }

    const Complex filter_coefficient =
      filter["coefficient"].complex_value();
    fbd.real_filter_coefficients[channel] = real(filter_coefficient);
    fbd.imag_filter_coefficients[channel] = imag(filter_coefficient);

    ComplexRowVector state_vector =
      filter["state"].complex_vector_value();
    if (state_vector.length() < gamma_order) {
      error("Gfb_Analyzer_fprocess: 1st argument must be a Gfb_Analyzer\n"
	    "       structure, and must contain a structure field named\n"
	    "       `filters', containing valid filter specifications.\n"
	    "       Use the Gfb_Analyzer_new function to construct a\n"
	    "       valid Gfb_Analyzer structure");
      return retval;
    }
    for (unsigned filter_stage = 0; filter_stage < gamma_order;
	 ++filter_stage) {
      const Complex & stage_state = state_vector.xelem(filter_stage);
      fbd.real_filter_state[filter_stage + channel*gamma_order] =
	real(stage_state);
      fbd.imag_filter_state[filter_stage + channel*gamma_order] =
	imag(stage_state);
    }
    fbd.normalization_factors[channel] =
      filter["normalization_factor"].double_value();
  }
  ComplexMatrix output(channels, samples);
  gfb_analyze_dd(channels, gamma_order, samples,
		 fbd.real_filter_coefficients, fbd.imag_filter_coefficients,
		 fbd.normalization_factors,
		 fbd.real_filter_state, fbd.imag_filter_state,
		 &input.xelem(0),
		 reinterpret_cast<double *>(&output.xelem(0,0)), 0);
  retval(0) = output;

  if (nargout == 2) {
    // return an updated copy of the Gfb_Analyzer struct
    retval(1) = analyzer;
    retval(1).make_unique();
    retval(1).struct_elt_ref("filters").make_unique();
    octave_value & filters = retval(1).struct_elt_ref("filters");
    for (unsigned channel = 0; channel < channels; ++channel) {
      std::string fieldname = filter_fieldname(channel + 1);

      const Complex
	filter_coefficient(fbd.real_filter_coefficients[channel],
			   fbd.imag_filter_coefficients[channel]);

      ComplexMatrix state_vector(1, gamma_order);
      for (unsigned filter_stage = 0; filter_stage < gamma_order;
	   ++filter_stage) {
	state_vector.xelem(0, filter_stage) =
	  Complex(fbd.real_filter_state[filter_stage
				       + channel*gamma_order],
		  fbd.imag_filter_state[filter_stage
				       + channel*gamma_order]);
      }
      filters.struct_elt_ref(fieldname).make_unique();
      filters.struct_elt_ref(fieldname).struct_elt_ref("state").
	make_unique();
      filters.struct_elt_ref(fieldname).struct_elt_ref("state") =
	state_vector;
    }
  }
  return retval;
}

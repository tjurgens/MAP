/* 
 * This file is part of the gammatone filterbank reference implementation
 * described in V. Hohmann's `acta acustica' article.
 *
 * It implements the filter bank analysis as a C function, and can be
 * incorporated into matlab or octave as described in file
 * "README_extension.txt".
 *
 * filename : Gfb_analyze.c
 * copyright: Universitaet Oldenburg
 * author   : tp
 * date     : Jan 2002
 *
 * update   : 
 */

/*-----------------------------------------------------------------------------
 *   Copyright (C) 2002   AG Medizinische Physik,
 *                        Universitaet Oldenburg, Germany
 *                        http://www.physik.uni-oldenburg.de/docs/medi
 *   
 *   Permission to use, copy, and distribute this software/file and its
 *   documentation for any purpose without permission by UNIVERSITAET OLDENBURG
 *   is not granted.
 *   
 *   Permission to use this software for academic purposes is generally
 *   granted.
 *
 *   Permission to modify the software is granted, but not the right to
 *   distribute the modified code.
 *
 *   This software is provided "as is" without expressed or implied warranty.
 *
 *   Author: Tobias Peters (tobias@medi.physik.uni-oldenburg.de)
 *---------------------------------------------------------------------------*/

#include "Gfb_analyze.h"

#ifndef COMP_FLOAT

/*
 * This file includes itself three times with different Preprocessor
 * definitions for
 *   COMP_FLOAT  --  the data type used for filterbank analysis computation
 *   EXCH_FLOAT  --  the data type used for exchanging input and output with
 *                   the calling function
 *   analyze     --  the name of the function that uses this combination of
 *                   data types
 * This way we avoid the need for C++ (templates!).
 */

#undef  COMP_FLOAT
#define COMP_FLOAT double
#undef  EXCH_FLOAT
#define EXCH_FLOAT double
#undef  analyze
#define analyze    gfb_analyze_dd
#include "Gfb_analyze.c"


#undef  COMP_FLOAT
#define COMP_FLOAT float
#undef  EXCH_FLOAT
#define EXCH_FLOAT double
#undef  analyze
#define analyze    gfb_analyze_df
#include "Gfb_analyze.c"


#undef  COMP_FLOAT
#define COMP_FLOAT float
#undef  EXCH_FLOAT
#define EXCH_FLOAT float
#undef  analyze
#define analyze    gfb_analyze_ff
#include "Gfb_analyze.c" 

#undef  COMP_FLOAT
#undef  EXCH_FLOAT
#undef  analyze

#else

void analyze(const unsigned           channels,
	     const unsigned           gamma,
	     const unsigned           samples,
	     const COMP_FLOAT * const real_filter_coefficients,
	     const COMP_FLOAT * const imag_filter_coefficients,
	     const COMP_FLOAT * const normalization_factors,
	     COMP_FLOAT * const       real_filter_states,
	     COMP_FLOAT * const       imag_filter_states,
	     const EXCH_FLOAT *       input,
	     EXCH_FLOAT *             output1,
	     EXCH_FLOAT *             output2)
{
    unsigned sample, channel, filter_stage;
    for (sample = 0; sample < samples; ++sample) {
        for (channel = 0; channel < channels; ++channel) {
            COMP_FLOAT re_tmp =
                (real_filter_states[channel * gamma]
                 * real_filter_coefficients[channel])
                - (imag_filter_states[channel * gamma]
                   * imag_filter_coefficients[channel])
                + input[sample] * normalization_factors[channel];
            
            imag_filter_states[channel * gamma] =
                (real_filter_states[channel * gamma]
                 * imag_filter_coefficients[channel])
                + (imag_filter_states[channel * gamma]
                   * real_filter_coefficients[channel]);

            real_filter_states[channel * gamma] = re_tmp;

            for (filter_stage = 1; filter_stage < gamma; ++filter_stage) {
                re_tmp =
                    (real_filter_states[channel * gamma + filter_stage]
                     * real_filter_coefficients[channel])
                    - (imag_filter_states[channel * gamma + filter_stage]
                       * imag_filter_coefficients[channel])
                    + real_filter_states[channel * gamma + filter_stage - 1];
                
                imag_filter_states[channel * gamma + filter_stage] =
                    (real_filter_states[channel * gamma + filter_stage]
                     * imag_filter_coefficients[channel])
                    + (imag_filter_states[channel * gamma + filter_stage]
                       * real_filter_coefficients[channel])
                    + imag_filter_states[channel * gamma + filter_stage - 1];
                
                real_filter_states[channel * gamma + filter_stage] = re_tmp;
            }
            *output1++ = re_tmp;
	    if (output2) {
	      *output2++ =
                imag_filter_states[(channel + 1) * gamma - 1];
	    }
	    else {
	      /* output2 == NULL: interlace real and imaginary values */
	      *output1++ =
                imag_filter_states[(channel + 1) * gamma - 1];
	    }
        }
    }
}
#endif
